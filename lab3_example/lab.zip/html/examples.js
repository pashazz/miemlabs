var examples =
[
    [ "/home/pasha/projects/labs/lab3_example/main.cpp", "_2home_2pasha_2projects_2labs_2lab3_example_2main_8cpp-example.html", null ]
];